"""
Деление
"""
def division(div_1, div_2):
    """
            Нахождение частного двух чисел.

            :param div_1: Первое число.
            :type div_1: int or float
            :param div_2: Второе число.
            :type div_2: int or float
            :return: Деление двух чисел.
            :rtype: int or float
        """
    return print(f'Частное чисел {div_1} и {div_2} = {div_1 / div_2}')
