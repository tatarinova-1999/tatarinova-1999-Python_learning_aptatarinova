"""
Калькулятор
"""
from modules1 import addition
from modules1 import subtraction
from modules1 import multiplication
from modules1 import division


def operation():
    """
    Выбор операции над числами.
    :return:
    """
    while True:
        command = int(input("""Выбирете операцию над числеми: 
        0. Выход из программы 
        1. Сложение 
        2. Вычитание 
        3. Умножение 
        4. Деление \n"""))
        if command == 0:
            break
        elif command == 1:
            add_1 = float(input('Введите первое слагаемое: '))
            add_2 = float(input('Введите второе слагаемое: '))
            addition(add_1, add_2)
        elif command == 2:
            sub_1 = float(input('Введите уменьшаемое: '))
            sub_2 = float(input('Введите вычитаемое: '))
            subtraction(sub_1, sub_2)
        elif command == 3:
            mult_1 = float(input('Введите первый множитель: '))
            mult_2 = float(input('Введите второй множитель: '))
            multiplication(mult_1, mult_2)
        elif command == 4:
            div_1 = float(input('Введите делимое: '))
            div_2 = float(input('Введите делитель: '))
            division(div_1, div_2)
        else:
            print('Операция не найдена')

