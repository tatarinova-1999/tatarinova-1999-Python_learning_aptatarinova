"""
Сложение
"""
def addition(add_1, add_2):
    """
        Нахождение суммы двух числел.

        :param add_1: Первое число.
        :type add_1: int or float
        :param add_2: Второе число.
        :type add_2: int or float
        :return: Сумма двух чисел.
        :rtype: int or float
    """
    return print(f'Сумма чисел {add_1} и {add_2} = {add_1 + add_2}')
