"""
Вычитание
"""
def subtraction(sub_1, sub_2):
    """
            Нахождение разности двух чисел.

            :param sub_1: Первое число.
            :type sub_1: int or float
            :param sub_2: Второе число.
            :type sub_2: int or float
            :return: Вычитание двух чисел.
            :rtype: int or float
        """
    return print(f'Разность чисел {sub_1} и {sub_2} = {sub_1 - sub_2}')
