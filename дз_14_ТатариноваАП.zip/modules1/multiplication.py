"""
Умножение
"""
def multiplication(mult_1, mult_2):
    """
            Нахождение произведения двых чисел.

            :param mult_1: Первое число.
            :type mult_1: int or float
            :param mult_2: Второе число.
            :type mult_2: int or float
            :return: Умножение двух чисел.
            :rtype: int or float
        """
    return print(f'Произведение чисел {mult_1} и {mult_2} = {mult_1 * mult_2}')
